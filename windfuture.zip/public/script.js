const canvas = document.getElementById('wind-canvas');
const ctx = canvas.getContext('2d');
const hero = document.querySelector('.hero');
const pauseToggle = document.getElementById('pause-toggle');
const pauseLabel = document.getElementById('pause-label');
const intensityRange = document.getElementById('intensity-range');
const intensityOutput = document.getElementById('intensity-output');
const velocityRange = document.getElementById('velocity-range');
const velocityOutput = document.getElementById('velocity-output');
const audioToggle = document.getElementById('audio-toggle');
const audioLabel = document.getElementById('audio-label');
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

let width = 0;
let height = 0;
let dpr = Math.min(window.devicePixelRatio || 1, 2);
let intensity = prefersReduced ? 0.2 : Number(intensityRange.value) / 100;
let velocity = prefersReduced ? 0.2 : Number(velocityRange.value) / 100;
let paused = prefersReduced;
let motionTime = 0;
let lastTimestamp = 0;
let particles = [];
let bursts = [];
const pointer = { x: 0, y: 0, active: false };

const palette = [
  'rgba(217,244,75,.46)',
  'rgba(230,239,197,.34)',
  'rgba(146,190,155,.28)',
  'rgba(232,137,93,.24)'
];
const particleCount = () => Math.min(300, Math.max(120, Math.floor(width / 4.5)));

const audio = {
  context: null,
  source: null,
  filter: null,
  gain: null,
  master: null,
  enabled: false
};

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  width = rect.width;
  height = rect.height;
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(width * dpr);
  canvas.height = Math.floor(height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  createParticles();
}

function createParticles() {
  particles = Array.from({ length: particleCount() }, (_, index) => {
    const x = Math.random() * width;
    const y = Math.random() * height;
    return {
      x,
      y,
      prevX: x,
      prevY: y,
      z: Math.random(),
      size: Math.random() * 1.8 + .3,
      speed: Math.random() * .55 + .25,
      vx: 0,
      vy: 0,
      color: palette[index % palette.length]
    };
  });
}

function flow(x, y, t) {
  const waveA = Math.sin(y * 0.008 + t * 0.00035) * 26;
  const waveB = Math.sin(y * 0.02 - t * 0.0002 + x * 0.003) * 11;
  return Math.sin((x * 0.006) + (y * 0.002) + t * 0.00015) * 0.55 + (waveA + waveB) * 0.016;
}

function drawStreamlines(time) {
  const spacing = Math.max(18, 42 - intensity * 16);
  const drift = velocity * 10;
  ctx.lineWidth = .7 + velocity * .35;
  for (let y = -40; y < height + 60; y += spacing) {
    ctx.beginPath();
    for (let x = -30; x < width + 30; x += 18) {
      const curve = flow(x, y, time) * (12 + intensity * 16 + velocity * 10);
      const yy = y + curve + Math.sin(x * .006 + time * .0002) * (3 + drift);
      if (x === -30) ctx.moveTo(x, yy); else ctx.lineTo(x, yy);
    }
    ctx.strokeStyle = `rgba(217,244,75,${0.035 + intensity * 0.045 + velocity * .02})`;
    ctx.stroke();
  }
}

function drawParticles(time) {
  particles.forEach((particle) => {
    const sway = flow(particle.x, particle.y, time) * (6 + particle.z * 8);
    particle.prevX = particle.x;
    particle.prevY = particle.y;

    if (!paused) {
      const baseSpeed = (particle.speed + particle.z * 1.4) * (0.25 + velocity * 1.8);
      particle.vx += baseSpeed * .08;

      if (pointer.active) {
        const dx = pointer.x - particle.x;
        const dy = pointer.y - particle.y;
        const distance = Math.max(18, Math.hypot(dx, dy));
        const influence = Math.max(0, 1 - distance / (260 + velocity * 110));
        const swirl = influence * (.45 + velocity * 1.55);
        particle.vx += (-dy / distance) * swirl;
        particle.vy += (dx / distance) * swirl;
        particle.vx += (dx / distance) * influence * .16;
        particle.vy += (dy / distance) * influence * .16;
      }

      particle.vx *= .91;
      particle.vy *= .91;
      particle.x += baseSpeed + particle.vx;
      particle.y += sway * .035 + particle.vy;
      if (particle.x > width + 20) { particle.x = -20; particle.y = Math.random() * height; }
      if (particle.y < -20) particle.y = height + 20;
      if (particle.y > height + 20) particle.y = -20;
    }

    const alpha = (0.3 + particle.z * .7) * (0.3 + intensity);
    ctx.strokeStyle = particle.color.replace(/\d?\.?\d+\)$/, `${alpha * .55})`);
    ctx.lineWidth = Math.max(.35, particle.size * .45);
    ctx.beginPath();
    ctx.moveTo(particle.prevX, particle.prevY);
    ctx.lineTo(particle.x, particle.y);
    ctx.stroke();

    ctx.fillStyle = particle.color.replace(/\d?\.?\d+\)$/, `${alpha})`);
    ctx.beginPath();
    ctx.arc(particle.x, particle.y, particle.size * (0.7 + particle.z), 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawBursts() {
  bursts = bursts.filter((burst) => burst.life > 0);
  bursts.forEach((burst) => {
    burst.life -= .028;
    burst.radius += 2.6 + velocity * 4;
    ctx.strokeStyle = `rgba(217,244,75,${burst.life * .36})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(burst.x, burst.y, burst.radius, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 8; i += 1) {
      const angle = burst.angle + i * (Math.PI / 4);
      const distance = burst.radius * .72;
      ctx.fillStyle = `rgba(230,239,197,${burst.life * .65})`;
      ctx.beginPath();
      ctx.arc(burst.x + Math.cos(angle) * distance, burst.y + Math.sin(angle) * distance, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function draw(timestamp = 0) {
  requestAnimationFrame(draw);
  const elapsed = lastTimestamp ? Math.min(40, timestamp - lastTimestamp) : 16;
  lastTimestamp = timestamp;
  if (!paused) motionTime += elapsed * (0.45 + velocity * 1.8);

  ctx.clearRect(0, 0, width, height);
  const gradient = ctx.createRadialGradient(width * .68, height * .45, 0, width * .68, height * .45, width * .72);
  gradient.addColorStop(0, 'rgba(96, 151, 111, .08)');
  gradient.addColorStop(1, 'rgba(16, 22, 21, 0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  drawStreamlines(motionTime);
  drawParticles(motionTime);
  drawBursts();
}

function setPaused(nextPaused) {
  paused = nextPaused;
  pauseToggle.setAttribute('aria-pressed', String(paused));
  pauseToggle.dataset.playing = String(!paused);
  pauseLabel.textContent = paused ? 'Play field' : 'Pause field';
}

function updateRangeOutput(output, value) {
  output.value = `${value}%`;
  output.textContent = `${value}%`;
}

function updateAudioShape() {
  if (!audio.context || !audio.filter || !audio.gain) return;
  const now = audio.context.currentTime;
  const cursorBias = pointer.active ? pointer.x / Math.max(1, width) : .5;
  const cursorLift = pointer.active ? 1 - pointer.y / Math.max(1, height) : .5;
  audio.filter.frequency.setTargetAtTime(260 + cursorBias * 900 + velocity * 360, now, .16);
  audio.gain.gain.setTargetAtTime(.025 + velocity * .075 + cursorLift * .025, now, .2);
}

function createWindSoundscape() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return false;

  const context = new AudioContext();
  const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < data.length; i += 1) {
    const white = Math.random() * 2 - 1;
    last = last * .985 + white * .015;
    data[i] = last * 3.2;
  }

  const source = context.createBufferSource();
  const highpass = context.createBiquadFilter();
  const filter = context.createBiquadFilter();
  const gain = context.createGain();
  const master = context.createGain();
  source.buffer = buffer;
  source.loop = true;
  highpass.type = 'highpass';
  highpass.frequency.value = 90;
  filter.type = 'lowpass';
  filter.frequency.value = 680;
  filter.Q.value = .45;
  gain.gain.value = .02;
  master.gain.value = 0;
  source.connect(highpass).connect(filter).connect(gain).connect(master).connect(context.destination);
  source.start();

  audio.context = context;
  audio.source = source;
  audio.filter = filter;
  audio.gain = gain;
  audio.master = master;
  return true;
}

async function toggleAudio() {
  if (!audio.context && !createWindSoundscape()) {
    audioLabel.textContent = 'Audio unavailable';
    return;
  }
  if (audio.context.state === 'suspended') await audio.context.resume();
  audio.enabled = !audio.enabled;
  const now = audio.context.currentTime;
  audio.master.gain.cancelScheduledValues(now);
  audio.master.gain.setTargetAtTime(audio.enabled ? .16 : 0, now, .22);
  audioToggle.setAttribute('aria-pressed', String(audio.enabled));
  audioToggle.dataset.active = String(audio.enabled);
  audioLabel.textContent = audio.enabled ? 'Sound on' : 'Sound off';
  updateAudioShape();
}

function triggerBurst(x, y) {
  bursts.push({ x, y, radius: 5, life: 1, angle: Math.random() * Math.PI * 2 });
  particles.slice(0, Math.min(20, particles.length)).forEach((particle, index) => {
    if (index % 2 === 0) {
      const dx = particle.x - x;
      const dy = particle.y - y;
      const distance = Math.max(30, Math.hypot(dx, dy));
      particle.vx += (dx / distance) * 2.2;
      particle.vy += (dy / distance) * 2.2;
    }
  });
}

pauseToggle.addEventListener('click', () => setPaused(!paused));
intensityRange.addEventListener('input', (event) => {
  intensity = Number(event.target.value) / 100;
  updateRangeOutput(intensityOutput, event.target.value);
});
velocityRange.addEventListener('input', (event) => {
  velocity = Number(event.target.value) / 100;
  updateRangeOutput(velocityOutput, event.target.value);
  updateAudioShape();
});
audioToggle.addEventListener('click', toggleAudio);

if (prefersReduced) {
  intensityRange.value = '20';
  velocityRange.value = '20';
  updateRangeOutput(intensityOutput, '20');
  updateRangeOutput(velocityOutput, '20');
}

hero.addEventListener('pointermove', (event) => {
  const rect = hero.getBoundingClientRect();
  const x = ((event.clientX - rect.left) / rect.width - .5) * 2;
  const y = ((event.clientY - rect.top) / rect.height - .5) * 2;
  pointer.x = event.clientX - rect.left;
  pointer.y = event.clientY - rect.top;
  pointer.active = true;
  hero.style.setProperty('--pointer-x', x.toFixed(3));
  hero.style.setProperty('--pointer-y', y.toFixed(3));
  updateAudioShape();
}, { passive: true });
hero.addEventListener('pointerleave', () => {
  pointer.active = false;
  hero.style.setProperty('--pointer-x', '0');
  hero.style.setProperty('--pointer-y', '0');
  updateAudioShape();
});
hero.addEventListener('pointerdown', (event) => {
  if (event.target.closest('button, a, input, label')) return;
  triggerBurst(pointer.x, pointer.y);
}, { passive: true });

window.addEventListener('resize', resizeCanvas, { passive: true });
resizeCanvas();
setPaused(paused);
draw();

const timelineData = [
  { year: '2025', value: 138 },
  { year: '2026', value: 140 },
  { year: '2027', value: 160 },
  { year: '2028', value: 167 },
  { year: '2029', value: 183 },
  { year: '2030', value: 194 }
];
const bars = document.getElementById('timeline-bars');
const maxValue = 200;
bars.innerHTML = timelineData.map((item, index) => `
  <div class="bar-wrap" style="--bar-height:${(item.value / maxValue) * 100}%; animation-delay:${index * 90}ms">
    <span class="bar-value">${item.value} GW</span>
    <div class="bar" style="height: var(--bar-height); animation-delay:${index * 90}ms"></div>
    <span class="bar-label">${item.year}</span>
  </div>
`).join('');

const revealItems = document.querySelectorAll('.stat-card, .process-step, .friction-card, .source-row');
if (!prefersReduced && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: .12 });
  revealItems.forEach((item, index) => {
    item.style.opacity = '0';
    item.style.transform = 'translateY(18px)';
    item.style.transition = `opacity .7s ${index * 45}ms ease, transform .7s ${index * 45}ms cubic-bezier(.22,.61,.36,1)`;
    observer.observe(item);
  });
}

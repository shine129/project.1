# Wind / Future — implementation plan

## Product direction
A polished one-page editorial experience that makes the future of wind energy feel physical: an animated airflow field is the hero visual, and the content translates credible capacity, cost, offshore, and grid facts into an easy narrative. The page is static and self-contained; no live weather feed is enabled because the confirmed blueprint left the optional Data API power-up unselected.

## Design system

- **Design movement:** speculative editorial / climate-instrument interface. Think field notes from a calm control room rather than a corporate sustainability page.
- **Core principles:** motion is the first storyteller; every large claim carries an observed/forecast label; data is legible before it is decorative; whitespace gives the page room to breathe.
- **Color philosophy:** deep mineral navy and soft warm white create a night-sky / paper contrast; chartreuse is the ownable “wind signal” color; rust-orange marks constraints and friction, not alarmism.
- **Layout paradigm:** asymmetric magazine composition with a full-bleed animated hero, a narrow metadata rail, large editorial pull quotes, and offset fact cards instead of a centered dashboard grid.
- **Signature elements:** animated streamlines, tiny mono “field-note” labels, and circular turbine-ring accents that echo a radar or anemometer.
- **Interaction philosophy:** controls are visible and tactile; pausing the wind and lowering intensity is treated as a legitimate reading mode, not an afterthought.
- **Animation:** a canvas field draws layered streamlines and particles at multiple depths. The controls change density and wind velocity, the pause button freezes the entire field, pointer movement adds restrained parallax plus a particle vortex, clicking the field creates a gust burst, and `prefers-reduced-motion` starts the experience in a calmer paused state.
- **Typography system:** `Space Grotesk` for display and body hierarchy, `IBM Plex Mono` for data labels, units, sources, and interface microcopy. Headlines are short, high-contrast, and use tight tracking.
- **Brand essence:** a visual field guide to what wind energy can actually become — clear, kinetic, grounded. Personality: curious, exacting, alive.
- **Brand voice:** plainspoken but atmospheric. Example lines: “The grid is learning to breathe.” / “Forecasts are not promises. They are a direction of travel.”
- **Wordmark & logo:** a slash-separated wordmark (`WIND / FUTURE`) paired with a small four-stroke gust mark; the slash acts like a horizon line.
- **Signature brand color:** signal chartreuse `#D9F44B`.

## Implementation

- `public/index.html`: semantic one-page narrative with navigation, hero canvas, fact cards, system explanation, constraints, timeline, and sources.
- `public/styles.css`: responsive editorial layout, theme tokens, cards, data bars, turbine motif, focus states, and reduced-motion fallback.
- `public/script.js`: canvas wind simulation, pause/intensity controls, accessible status updates, scroll reveal, and timeline bar animation.
- `public/manus-routes.json`: single `/` route declaration required by Webdev.
- `server.mjs`: dependency-free static server on `0.0.0.0:$PORT` (default 3000) for Preview.
- `package.json`: start script and pinned Node package metadata; no external runtime dependencies.
- `app.config.ts`: durable project logo metadata for the checkpoint.

## Visual refinement pass

- Kept the Space Grotesk / IBM Plex Mono pairing and strengthened its hierarchy with more intentional display emphasis, glow, and mono telemetry cues.
- Added a cinematic frame, drifting grid, signal breathing, card lift states, and pointer-responsive hero depth without changing the page narrative.
- Corrected the canvas pause behavior so both streamlines and particles freeze together; reduced-motion now also lowers the initial intensity control to match the calm state.
- Added a browser-native procedural wind soundscape that starts only after the reader enables it; cursor position shifts the filter and air level, while velocity changes the sound energy.
- Added separate particle-field and wind-velocity controls, cursor vortex forces, particle trails, and click-triggered gust rings.

## Facts and sources

- **1,136 GW cumulative wind capacity at end-2024; 117 GW added in 2024; 981 GW forecast for 2025–2030:** Global Wind Energy Council, Global Wind Report 2025 article.
- **Onshore wind additions expected to reach 732 GW over 2025–2030; offshore expansion expected to reach 140 GW:** IEA, Renewables 2025.
- **New onshore wind projects were 67% below the weighted-average fossil-fuel alternative in 2023:** IRENA, Renewable Power Generation Costs in 2023.
- Sources are linked inline so readers can audit every major claim.
